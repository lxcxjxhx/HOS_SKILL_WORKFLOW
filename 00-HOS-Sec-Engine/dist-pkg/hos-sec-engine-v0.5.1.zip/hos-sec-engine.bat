@echo off
title HOS-Sec-Engine v0.5.1
setlocal enabledelayedexpansion

set ENGINE_DIR=%~dp0
set CLI_PATH=%ENGINE_DIR%dist\src\cli\index.js

echo.
echo +------------------------------------------+
echo ^|  HOS-Sec-Engine v0.5.1                    ^|
echo ^|  HOS攻防实战规则引擎                          ^|
echo +------------------------------------------+
echo.

if "%1"=="" goto :help
if "%1"=="server" goto :server
if "%1"=="run" goto :run
if "%1"=="start" goto :start
if "%1"=="help" goto :help
goto :invalid

:server
  node "%CLI_PATH%" server %2 %3 %4 %5
  goto :end

:run
  node "%CLI_PATH%" run %2 %3 %4 %5
  goto :end

:start
  node "%ENGINE_DIR%dist\src\examples\process-guidance.js"
  goto :end

:help
  echo 用法: hos-sec-engine ^<command^> [options]
  echo.
  echo 命令:
  echo   server    启动 Agent 通信服务
  echo   run       执行技能
  echo   start     运行业务指导流程演示
  echo   help      显示此帮助
  echo.
  goto :end

:invalid
  echo 未知命令: %1
  echo 运行 "hos-sec-engine help" 查看可用命令
  goto :end

:end
  endlocal
